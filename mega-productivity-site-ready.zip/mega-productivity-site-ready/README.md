# Mega Productivity — Fullstack (Frontend + Backend)

Projeto fullstack (React + Tailwind frontend com Vite) e backend Express simples.
Pronto para extrair, abrir no VS Code, rodar localmente e enviar para o GitHub + deploy.

## Estrutura
- `frontend/` — app React (Vite) + Tailwind, pronto para deploy na Vercel
- `backend/` — Express API que persiste em `data.json`, pronta para deploy em Render/Railway

## Rodar localmente
1. Extraia o ZIP.
2. Abra a pasta no VS Code: `code .`
3. Instale dependências (root usa workspaces):
   ```bash
   npm install --workspaces
   ```
4. Rodar ambos (frontend em :5173 e backend em :4000):
   ```bash
   npm run start:backend   # roda backend
   npm run start:frontend  # roda frontend
   ```
   Ou rode ambos simultaneamente (requer `concurrently`):
   ```bash
   npm run start
   ```

## Deploy rápido (recomendado)
- Push para GitHub e use Vercel (frontend) + Render/Railway (backend).
- Configure `VITE_API_URL` na Vercel para apontar para o backend público.
