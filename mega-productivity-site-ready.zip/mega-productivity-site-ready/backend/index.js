import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import fs from 'fs-extra';
import path from 'path';

const __dirname = path.resolve();
const DATA_FILE = path.join(__dirname, 'data.json');
const app = express();
app.use(cors());
app.use(bodyParser.json());

async function readData(){ try{ if(!(await fs.pathExists(DATA_FILE))){ const base={tasks:[],notes:[],events:[],habits:[],pomodoro:{completed:0}}; await fs.writeJson(DATA_FILE, base, {spaces:2}); return base } return await fs.readJson(DATA_FILE) }catch(e){ return {tasks:[],notes:[],events:[],habits:[],pomodoro:{completed:0}} } }
async function writeData(d){ await fs.writeJson(DATA_FILE, d, {spaces:2}) }

app.get('/api/state', async (req,res)=> res.json(await readData()));
app.post('/api/tasks', async (req,res)=>{ const d=await readData(); const t={id:Date.now().toString(36),...req.body}; d.tasks.push(t); await writeData(d); res.json(t); });
app.put('/api/tasks/:id', async (req,res)=>{ const d=await readData(); d.tasks=d.tasks.map(t=>t.id===req.params.id?{...t,...req.body}:t); await writeData(d); res.json({ok:true}); });
app.delete('/api/tasks/:id', async (req,res)=>{ const d=await readData(); d.tasks=d.tasks.filter(t=>t.id!==req.params.id); await writeData(d); res.json({ok:true}); });

app.post('/api/notes', async (req,res)=>{ const d=await readData(); const n={id:Date.now().toString(36),createdAt:new Date().toISOString(),...req.body}; d.notes.push(n); await writeData(d); res.json(n); });
app.delete('/api/notes/:id', async (req,res)=>{ const d=await readData(); d.notes=d.notes.filter(n=>n.id!==req.params.id); await writeData(d); res.json({ok:true}); });

app.post('/api/events', async (req,res)=>{ const d=await readData(); const e={id:Date.now().toString(36),...req.body}; d.events.push(e); await writeData(d); res.json(e); });
app.delete('/api/events/:id', async (req,res)=>{ const d=await readData(); d.events=d.events.filter(e=>e.id!==req.params.id); await writeData(d); res.json({ok:true}); });

app.post('/api/habits', async (req,res)=>{ const d=await readData(); const h={id:Date.now().toString(36),days:[],...req.body}; d.habits.push(h); await writeData(d); res.json(h); });
app.post('/api/habits/:id/record', async (req,res)=>{ const d=await readData(); const h=d.habits.find(x=>x.id===req.params.id); if(!h) return res.status(404).json({error:'not found'}); const today=new Date().toISOString().slice(0,10); if(!h.days.includes(today)) h.days.push(today); await writeData(d); res.json({ok:true}); });

app.post('/api/pomodoro/complete', async (req,res)=>{ const d=await readData(); d.pomodoro.completed=(d.pomodoro.completed||0)+1; await writeData(d); res.json({completed:d.pomodoro.completed}); });

app.get('/api/health', (req,res)=> res.json({ok:true}));

const PORT = process.env.PORT || 4000;
app.listen(PORT, ()=> console.log('Backend running on', PORT));
